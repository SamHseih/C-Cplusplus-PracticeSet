class Pokemon
{
public:
    void ShowInfo();
 
    ...
};
