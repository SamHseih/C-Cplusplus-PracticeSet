int Square::area()
{
//...
}
