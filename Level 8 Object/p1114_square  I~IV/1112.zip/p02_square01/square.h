class Square
{
//...
};
